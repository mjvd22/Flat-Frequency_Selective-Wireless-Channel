% Theoretic Error Probability 
clc; clear; %close all;

%% Defining Parameters
a = 1;
SNR = linspace( -20, 20, 1000);
% N0 = a^2./10.^(SNR/10);

gamma = 10.^(SNR/10);
Pe_avg131 = 0.5*( 1 - (gamma./(1+gamma)).^0.5);

% hold on 
figure(131);
semilogy(SNR, Pe_avg131,DisplayName= "Theoretical $Pe_{avg}$");
xlabel(" SNR (dB)", Interpreter="latex");
ylabel("Theoretical Average Error Probability", Interpreter="latex");
title("Theoretical Average Error Probability in Q3", Interpreter="latex");
legend(Interpreter="latex")
grid on 

%% Defining Parameters
% Error Probability using Simulation
num = 1e5;

a = 1;
SNR = linspace( -20, 20, 1000);
n = length(SNR);
N0 = a^2./10.^(SNR/10);

%% Defining Channel Coefficients and Noise
N = repmat(N0, [num, 1]);
rng("shuffle")
hr = sqrt(1/2)*randn( num, n);
hi = sqrt(1/2)*randn( num, n);
h = hr +1j.*hi;
clear hr hi;
wr = sqrt(N/2).*randn( num, n);
wi = sqrt(N/2).*randn( num, n);
w = wr+1j.*wi;
clear wr wi
%% Generating symbols and receiver
x = a*( 2*randi([0, 1], [num, n])-ones( num, n));

noiser = (conj(h).*w)./(abs(h).^2);

zr = x + noiser;
logi = zr.*x < 0;
prob132= sum(logi)/num;

figure(132);
semilogy( SNR, prob132, DisplayName="Actual Error Probability");
hold on
xlabel(" SNR (dB)", Interpreter="latex");
ylabel("Average Error Probability", Interpreter="latex");
title("Average Error Probability in Part3 (Simulation)", Interpreter="latex");
semilogy(SNR, Pe_avg131,DisplayName= "Theoretical $Pe_{avg}$");
legend(Interpreter="latex")
grid on 

save("../Part3/prob131.mat", "Pe_avg131");
save("../Part4/prob131.mat", "Pe_avg131");
save("../Part3/prob132.mat", "prob132");

hold off

figure(1322);
p1 = load("prob121.mat").pb121;
p2 = load("prob122.mat").prob_b122;
p3 = load("prob131.mat").Pe_avg131;
p4 = load("prob132.mat").prob132;

semilogy( SNR, p1, SNR, p2, SNR, p3,SNR, p4,LineWidth= 1.5);
legend([" Theorical AWGN Coding", "Simulation AWGN Coding", "Theorical Rayleigh", "Simulation Rayleigh"], Interpreter="latex");
xlabel(" SNR (dB)", Interpreter="latex");
ylabel("Average Error Probability", Interpreter="latex");
title("Rayleigh Channel with Known Coefficients and AWGN with Coding ", Interpreter="latex", FontSize=8)
xlim([-15 16])
grid on