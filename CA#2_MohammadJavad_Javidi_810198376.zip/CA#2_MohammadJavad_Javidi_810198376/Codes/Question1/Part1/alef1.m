clear; clc; close all;
%% Defining Parameters
num = 1e5;
a = 1;
SNR = linspace(-20, 20, 1000);

N0 = a^2./10.^(SNR/10);
% in rows we have different SNRs and in columns we have different channels
N = repmat(N0, [num, 1]);
n = length(N0);
%% Defining noise and channel 
 % Generating Gaussian noise
wr = sqrt(N/2).*randn( num, n);
wi = sqrt(N/2).*randn( num, n);
% Generating Gaussian Channel Coefficients
hr = sqrt(1/2)*randn(num, n);
hi = sqrt(1/2)*randn(num, n);
%% Generating channel
symb = a*(2*randi([0, 1], [num, n])-ones(num, n));

yr = symb.*hr + wr;
yi = symb.*hi + wi;

%% Decision making 
y_decis = (yr + yi)/2;
% if a < 0 and y_decis > 0 or a > 0 and y_decis < 0 it is error
logi = y_decis.*symb < 0;
prob_111 = sum(logi)/num;


figure(111);
plot( SNR, prob_111);
xlabel('SNR (dB)', 'Interpreter','latex');
ylabel('BER', 'Interpreter','latex');
ylim([0 1]);
title('Bit Error Rate in Fading Channel of BPSK Mod.', 'Interpreter','latex');
grid on

%% Defining Parameters
num = 1e5;
a = 1;
SNR = linspace(-20, 20, 1000);

N0 = a^2./10.^(SNR/10);

N = repmat(N0, [num, 1]);
n = length(N0);
%% Defining noise and channel 

wr = sqrt(N/2).*randn( num, n);
wi = sqrt(N/2).*randn( num, n);
%% Generating channel

symb = a*(2*randi([0, 1], [num, n])-ones(num, n));

yr = symb + wr;
yi = symb + wi;
%% Decision making 
logi = ((yr + 1j.*yi)./2).*symb < 0;
prob112 = sum(logi)/num;


figure(112);
semilogy(SNR, prob112,'DisplayName','Actual BER');
ylim([1e-6 1]);
xlabel('SNR (dB)',Interpreter='latex');
ylabel('BER',Interpreter='latex');
title('Bit Error Rate of BPSK Mod. without Fading',Interpreter='latex');
grid on

hold on
semilogy(SNR, qfunc(sqrt(2.* (10.^(SNR./10))   )),'DisplayName','Theoretic BER');
legend(Interpreter="latex")
