clear ; clc; close all;
%% Defining Parameters
num = 5*1e5;
SNR = linspace(-20, 60, 100);
n = length(SNR);

a = 1;
N0 = a^2./10.^(SNR/10);

N = repmat(N0, [num, 1]);
%% Defining Channel Coefficients and Noise
hr1 = sqrt(1/2)*randn( num, n);
hi1 = sqrt(1/2)*randn( num, n);
h1 = hr1 + 1j.*hi1;
clear hr1 hi1

hr2 = sqrt(1/2)*randn( num, n);
hi2 = sqrt(1/2)*randn( num, n);
h2 = hr2 + 1j.*hi2;
clear hr2 hi2

wr1 = sqrt(N/2).*randn( num, n);
wi1 = sqrt(N/2).*randn( num, n);
w1 = wr1 + 1j.*wi1;
clear wr1 wi1

wr2 = sqrt(N/2).*randn( num, n);
wi2 = sqrt(N/2).*randn( num, n);
w2 = wr2 + 1j.*wi2;
clear wr2 wi2
%% Generating Bits
u1 = a*( 2*randi([0, 1], [num, n])-ones( num, n));
u2 = a*( 2*randi([0, 1], [num, n])-ones( num, n));


ym1 = h1.*u1 + h2.*u2 + w1;

ym2 = conj(h2).*u1 - conj(h1).*u2 + w2;

s1 = conj(h1).*ym1 + h2.*conj(ym2);
s2 = conj(h2).*ym1 - h1.*conj(ym2);

pe162 = 1/(2*num)*( sum(s1.*u1 < 0) + sum( s2.*u2 < 0));

figure(162);
semilogy( SNR, pe162);

xlabel(" SNR (dB)", Interpreter="latex");
ylabel("Average Error Probability", Interpreter="latex");
title("Average Error Probability with Alamouti Code", Interpreter="latex")
grid on