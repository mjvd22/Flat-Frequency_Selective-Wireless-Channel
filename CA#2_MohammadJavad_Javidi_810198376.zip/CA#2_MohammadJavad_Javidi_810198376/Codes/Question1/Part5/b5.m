clear; clc; %close all;
%% Defining Parameters
SNR = linspace(-10, 20, 500);
gm = 10.^(SNR/10);
g = (gm./(1+gm)).^0.5;
n = length(SNR);

p152a = zeros( 5, n); % Theoretic Error Prob
p152b = zeros( 5, n); % Simulation Error Prob
for L = 1: 5 
    p152b( L, :) = mrc( L, SNR);
end

p152a(1, :) = (1-g)/2;
p152a(2, :) = (0.5-0.5*g).^2.*(2+g);
p152a(3, :) = (0.5-0.5*g).^3.*(1+3*(1+g)/2+6*(0.5+0.5*g).^2);
p152a(4, :) = (0.5-0.5*g).^4.*(1+4*(0.5+0.5*g)+10*(0.5+0.5*g).^2+20*(0.5+0.5*g).^3);
p152a(5, :) = (0.5-0.5*g).^5.*(1+5*(0.5+0.5*g)+15*(0.5+0.5*g).^2+35*(0.5+0.5*g).^3+70*(0.5+0.5*g).^4);


figure(152);
semilogy( SNR, p152b(1, :), SNR, p152b(2, :), SNR, p152b(3, :), SNR, p152b(3, :)...
    , SNR, p152b(4, :), SNR, p152b(5, :), SNR, p152a(1, :), SNR, p152a(2, :),...
     SNR, p152a(3, :), SNR, p152a(4, :), SNR, p152a(5, :));
legend(["L = 1, sim.", "L = 2, sim.", "L = 3, sim.", "L = 4, sim.", "L = 5, sim."...
    , "L = 1, Theo.", "L = 2, theo.", "L = 3, theo.", "L = 4, theo.", "L = 5, theo. "], Interpreter="latex");
xlabel(" SNR (dB)", Interpreter="latex");
ylabel("Average Error Probability", Interpreter="latex");
title("Average Error Probability in BPSK with Maximal Ratio Combining", Interpreter="latex");
grid on 