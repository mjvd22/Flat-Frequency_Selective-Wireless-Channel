clear; clc; %close all
%% Defining Parameters
    BitPerSymbol=1; % bit/symbol
    NoSymbols=5*10^6; % symbol numbers
    NoSub=10^4; % Subcarries number
    p_max = NoSub;
    LenCyclic=199; % Length of Cyclic prefix
    SNR=20:-1:-20;
    L = 10; % Num of Branches
%     BPSKNum=2; % Phase number of BPSK
%% BPSK Symbol Making 
    % Gnerate Data Sequence
    NoBits=NoSymbols;
    data=randi([0 1],1,NoBits);
    % Separate data to different path and different SNR
    path=reshape(data,NoSub,NoBits/NoSub);
    % BPSK
    BPSKpath=2.*path - ones(NoSub,NoBits/NoSub);
    % Generating L-paths
    BPSKbranch = repmat(BPSKpath, [1, 1, L]);
    clear path main_path;
%% MRC
%     BER = zeros(size(SNR));
    BER = MRC(L, SNR, BPSKbranch, p_max, NoSub, LenCyclic, data);
%% Plot result
    fig(1) = figure;
    semilogy(SNR,BER);
    grid on
    xlabel('SNR[dB]', Interpreter='latex');
    ylabel('BER', Interpreter='latex');
    title(['OFDM with MRC ', num2str(L), '-branch'], Interpreter='latex')
%% Functions
function Pe = MRC(L, SNR, BPSKbranch, p_max, NoSub, LenCyclic, data)
    N_0 = (p_max./((10.^(SNR./10)) *NoSub) )'; % Noise Energy
    for SnrNo = 1:length(SNR)
        rng(1)
    
        % channel coefficients
        hr_main = sqrt(0.5).*randn(LenCyclic+1, 1, L);
        hi_main = sqrt(0.5).*randn(LenCyclic+1, 1, L);
        h_main = hr_main + 1j.*hi_main;
        h = repmat(h_main, [1, size(BPSKbranch, 2), 1]);
        H = fft(h, NoSub, 1);
        % Adding CP and Transmitting
        % ifft
        ifftpath=ifft(BPSKbranch,NoSub, 1);
        % Add cyclic prefix
        Tranpath=zeros(size(ifftpath,1)+LenCyclic,size(ifftpath,2),size(ifftpath,3));
        Tranpath(1:LenCyclic,:, :)=ifftpath((end-LenCyclic+1):end,:, :);
        Tranpath((1+LenCyclic):end,:, :)=ifftpath;
         
        % Transmitting
        Repath = transmit(h_main, Tranpath);
        
        % noise generating
        ni = sqrt(N_0(SnrNo)/2).*randn(size(Repath));
        nr = sqrt(N_0(SnrNo)/2).*randn(size(Repath));
        n = nr+1j.*ni;
        clear ni nr;

        Repath = Repath + n;
        
        % Receiver and Decision making

        % Remove cyclic prefix
        ReCyclicpath = Repath((1+LenCyclic):end,:, :);
        % fft
        fftpath=fft(ReCyclicpath,NoSub, 1);
        
        % Combining
        Repath_cmb = sum(fftpath.*conj(H), 3); 

        % Reform
        demodata=reshape(real(Repath_cmb),[1,size(fftpath,1)*size(fftpath,2)]);
%         data_branch = repmat(data, [1, ]);
        % Calculate BER
        Pe(SnrNo)=sum(demodata.*(2.*data - 1) < 0 )/(size(fftpath,1)*size(fftpath,2));
        
    end
end
function res = transmit(chnl, data)
     res = zeros(size(data));
     for branch = 1: size(data, 3)
        parfor block = 1:size(data, 2)
%                 res(:, block) = filter(chnl(:, 1, branch), 1, data(:, block, branch));
                res(:, block, branch) = cconv(data(:, block, branch), chnl(:, 1, branch), length(data(:, block, branch)));
        end
     end
end