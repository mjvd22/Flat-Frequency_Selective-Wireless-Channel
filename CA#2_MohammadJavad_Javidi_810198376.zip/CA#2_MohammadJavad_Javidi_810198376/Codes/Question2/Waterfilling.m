clear; clc; %close all
%% Defining Parameters
    BitPerSymbol=1; % bit/symbol
    NoSymbols=10^6; % symbol numbers
    NoSub=10^4; % Subcarries number
    LenCyclic=199; % Length of Cyclic prefix
    SNR=-20:5:20;
%     BPSKNum=2; % Phase number of BPSK
%% BPSK Symbol Making 
    % Gnerate Data Sequence
    NoBits=NoSymbols*BitPerSymbol;
    data=randi([0 1],1,NoBits);
    % Separate data to different path and different SNR
    path=reshape(data,NoSub,NoBits/NoSub);
    % BPSK
    BPSKpath=2.*path - ones(NoSub,NoBits/NoSub);
    clear path main_path;
%% Waterfilling
    hi_main = sqrt(0.5).*randn(LenCyclic + 1, 1);
    hr_main = sqrt(0.5).*randn(LenCyclic + 1, 1);
    h_main = hr_main+1j.*hi_main;
    h = repmat(h_main, [1, NoBits/NoSub]);
    H = fft(h, NoSub, 1);
    clear hi_main hr_main;
    p_max = NoSub;
    N_0 = (p_max./((10.^(SNR./10)) *NoSub) )'; % Noise Energy

    parfor i=1:length(SNR)
        eps = 0.01;
        a1 = max(N_0(i)/(abs(H(:, 1)).^2));
        a2 = min(N_0(i)/(abs(H(:, 1)).^2));
        if isinf(1/a2)
            a2 = 1e2; 
        end
        lambda_init = [eps]; % initial Value
        lambda(i) = Waterfill(p_max, lambda_init, H(:, 1), N_0(i));
        
    end
    
    BER=zeros(size(SNR));
    Cap = zeros(size(SNR));
    % main loop of system
    for i=1:length(SNR)
        P = sqrt((max(1/lambda(i) - N_0(i)./(abs(H).^2) , 0))).*exp(-1j.*angle(H));
        BPSKpath_Wtrfil = P.*BPSKpath;
    % Adding CP and Transmitting
        % ifft
        ifftpath=ifft(BPSKpath_Wtrfil,NoSub, 1);
        % Add cyclic prefix
        Tranpath=zeros(size(ifftpath,1)+LenCyclic,size(ifftpath,2));
        Tranpath(1:LenCyclic,:)=ifftpath((end-LenCyclic+1):end,:);
        Tranpath((1+LenCyclic):end,:)=ifftpath;
         
        % Transmitting
        Repath = zeros(size(Tranpath));
        parfor j = 1:NoBits/NoSub
           Repath(:, j) = filter(h_main, 1, Tranpath(:, j));
        end

        % Generate Noise
        ni = sqrt(N_0(i)/2).*randn(size(Repath));
        nr = sqrt(N_0(i)/2).*randn(size(Repath));
        n = nr+1j.*ni;
        clear ni nr;
        Repath = Repath + n; % Transmitted signal
        
        % Receiver and Decision making

        % Remove cyclic prefix
        ReCyclicpath = Repath((1+LenCyclic):end,:);
        % fft
        fftpath=fft(ReCyclicpath,NoSub, 1);
        % Reform
        demodata=reshape(real(fftpath),1,NoBits);
        % Calculate BER
        BER(i)=sum(demodata.*(2.*data - 1) < 0 )/NoBits;
        Cap(i)=sum( log10( 1 + P(:, 1).*abs(H(:, 1).^2)./N_0(i)));
        disp(['SNR: ' num2str(SNR(i)) '. BER: ' num2str(BER(i))])

    end
%% Plot result
    fig(1) = figure;
    semilogy(SNR,BER, "--dr");
    grid on
    xlabel('SNR[dB]', Interpreter='latex');
    ylabel('BER', Interpreter='latex');
    title('OFDM with Waterfiling', Interpreter='latex')
    fig(2) = figure;
    semilogy(SNR,Cap, "--dr");
    grid on
    xlabel('SNR[dB]', Interpreter='latex');
    ylabel('Bits/OFDM Symbol', Interpreter='latex');
    title('Capacity OFDM Channel with Waterfiling', Interpreter='latex')
%% Functions
function res = Waterfill(p_max, lambda_init, H, N_0)
        syms lambda_loop
        f(lambda_loop) = p_max - sum(max( (1./lambda_loop - N_0./( abs(H).^2 ) ), 0)) ;
        res = fzero(f, lambda_init);
end