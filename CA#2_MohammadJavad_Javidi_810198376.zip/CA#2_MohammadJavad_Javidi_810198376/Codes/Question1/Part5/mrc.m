function p = mrc(L, SNR)
num = 1e5;
a = 1;

n = length(SNR);
N0 = a^2./10.^(SNR/10);

N = repmat(N0, [num, 1]);
nr = zeros( num, n, L);
ni = zeros( num, n, L);

hr = zeros( num, n, L);
hi = zeros( num, n, L);

for i = 1: L
    hr(:, :, i) = sqrt(1/2)*randn( num, n);
    hi(:, :, i) = sqrt(1/2)*randn( num, n);
    nr(:, :, i) = sqrt(N/2).*randn( num, n);
    ni(:, :, i) = sqrt(N/2).*randn( num, n);
end
noiset = sum( hr.*nr + hi.*ni, 3);

r = sum( hr.^2 + hi.^2, 3);

x = a*( 2*randi([0, 1], [num, n])-ones( num, n));

y = x.*r + noiset;

p = sum( y.*x < 0)/num;
end



