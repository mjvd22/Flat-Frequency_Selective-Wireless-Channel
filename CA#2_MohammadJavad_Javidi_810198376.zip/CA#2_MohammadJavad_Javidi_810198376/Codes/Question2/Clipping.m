clear; clc; %close all;
%% Defining Parameters
    BitPerSymbol=1; % bit/symbol
    NoSymbols=5*10^6; % symbol numbers
    NoSub=10^4; % Subcarries number
    p_max = NoSub/10;
    LenCyclic=199; % Length of Cyclic prefix
    SNR=40:-1:-0;
%     eqz_opt_1 = "ZF"; % Equalizer Type
    eqz_opt_2 = "MMSE"; % Equalizer Type
    max_clp = 0.8; % Accepted Maximmum Amplitude in Amplifier 
%     BPSKNum=2; % Phase number of BPSK
%% BPSK Symbol Making 
    % Gnerate Data Sequence
    NoBits=NoSymbols;
    rng("shuffle")
    data=randi([0 1],1,NoBits);
    % Separate data to different path and different SNR
    path=reshape(data,NoSub,NoBits/NoSub);
    % BPSK
    BPSKpath=2.*path - ones(NoSub,NoBits/NoSub);
    clear path main_path;
%% Equalizer
    
%     BER_Clp_ZF = clipping(SNR, BPSKpath, p_max, NoSub, LenCyclic, data, eqz_opt_1, max_clp);
%     BER_ZF = clipping(SNR, BPSKpath, p_max, NoSub, LenCyclic, data, eqz_opt_1, 1);
    BER_Clp_MMSE = clipping(SNR, BPSKpath, p_max, NoSub, LenCyclic, data, eqz_opt_2, max_clp);
    BER_MMSE = clipping(SNR, BPSKpath, p_max, NoSub, LenCyclic, data, eqz_opt_2, 1);
%% Plot result
%     fig(1) = figure;
%     semilogy(SNR,BER_Clp_ZF, DisplayName="ZF method with Clipping");
%     grid on
%     hold on
%     semilogy(SNR,BER_ZF, DisplayName="ZF method without Clipping");
%     xlabel('SNR[dB]', Interpreter='latex');
%     ylabel('BER', Interpreter='latex');
%     title(["OFDM with ZF method and clipping factor :", num2str(max_clp)], Interpreter='latex')
%     legend(Interpreter="latex")
    
    fig(2) = figure;
    semilogy(SNR,BER_Clp_MMSE, '--o', DisplayName="MMSE method with Clipping");
    grid on
    hold on
    semilogy(SNR,BER_MMSE, '--*', DisplayName="MMSE method without Clipping");
    xlabel('SNR[dB]', Interpreter='latex');
    ylabel('BER', Interpreter='latex');
    title(["OFDM with MMSE methodand clipping factor :", num2str(0.8)], Interpreter='latex');
    legend(Interpreter="latex")
%% Functions
function Pe = clipping(SNR, BPSKpath, p_max, NoSub, LenCyclic, data, eqz_opt, max_clp)
    N_0 = (p_max./((10.^(SNR./10)) *NoSub) )'; % Noise Energy
    for SnrNo = 1:length(SNR)
        rng(1)
    
        % channel coefficients
        hr_main = sqrt(0.5).*randn(LenCyclic+1, 1);
        hi_main = sqrt(0.5).*randn(LenCyclic+1, 1);
        h_main = hr_main + 1j.*hi_main;
        h = repmat(h_main, [1, size(BPSKpath, 2)]);
        H = fft(h, NoSub, 1);

        % Adding CP and Transmitting
        % ifft
        ifftpath=ifft(BPSKpath,NoSub, 1);
        ifftpath_clp = Non_Pwr_Amp(ifftpath, max_clp);
        % Add cyclic prefix
        Tranpath=zeros(size(ifftpath_clp,1)+LenCyclic,size(ifftpath_clp,2));
        Tranpath(1:LenCyclic,:, :)=ifftpath_clp((end-LenCyclic+1):end,:);
        Tranpath((1+LenCyclic):end,:)=ifftpath_clp;
         
        % Transmitting
        Repath = transmit(h_main, Tranpath);
        
        % noise generating
        ni = sqrt(N_0(SnrNo)/2).*randn(size(Repath));
        nr = sqrt(N_0(SnrNo)/2).*randn(size(Repath));
        n = nr+1j.*ni;
%         clear ni nr;

        Repath = Repath + n;
        
        % Receiver and Decision making

        % Remove cyclic prefix
        ReCyclicpath = Repath((1+LenCyclic):end,:);
        % fft
        fftpath=fft(ReCyclicpath,NoSub, 1);
        
        % Eqz
        if (eqz_opt == "ZF")
            Repath_eqz = fftpath./H;
        elseif(eqz_opt == "MMSE")
            Repath_eqz = fftpath.*( conj(H)./(H.*conj(H) + repmat(N_0(SnrNo), size(H))) );
%             Repath_eqz = fftpath.*( conj(H)./(abs(H.^2)) );
        end


        % Reform
        demodata=reshape((Repath_eqz),[1,size(fftpath,1)*size(fftpath,2)]);
        % Calculate BER
        Pe(SnrNo)=sum(demodata.*(2.*data - 1) < 0 )/(size(fftpath,1)*size(fftpath,2));
        
    end
end
function res = transmit(chnl, data)
     res = zeros(size(data));
    for block = 1:size(data, 2)
        res(:, block) = cconv(data(:, block), chnl, length(data(:, block)));
    end
    
end
function res = Non_Pwr_Amp(data, max_amp)
    res = data;
    MAX = max(data, [], "all");
%     idx = [mod(idx, size(data, 1)), mod(idx, size(data, 2))];
    res(abs(data) >= max_amp*abs(MAX)) = max_amp*(MAX);
end