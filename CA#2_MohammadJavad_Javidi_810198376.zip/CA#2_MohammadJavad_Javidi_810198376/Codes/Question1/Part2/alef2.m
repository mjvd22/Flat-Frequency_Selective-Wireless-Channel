clear; clc;
%% Generating Theoretic BER

SNR = linspace(-20, 20, 1000);
pb121 =qfunc(10.^(SNR/20));

figure(121);
semilogy(SNR, pb121, DisplayName= "Theoretic BER");
xlabel(" SNR (dB)", Interpreter="latex");
ylabel("BER", Interpreter="latex");
title("Theoretic Bit Error Rate for Q2", Interpreter="latex");
grid on 

% Generating Actual BER 
%% Defining Parameters
num = 1e5;

a = 1;
SNR = linspace(-20, 20, 1000);
N0 = a^2./10.^(SNR/10);
N = repmat(N0, [num, 1]);

n = length(SNR);
%% Defining Channel
bit = randi([0,1], [ num, n]);

wr_1 = sqrt(N/2).*randn( num, n);
wr_2 = sqrt(N/2).*randn(num, n);

% let's define the symbols in two arrays
s_1 = a*(bit == 0);
s_2 = a*(bit == 1);

y_1 = s_1 + wr_1;
y_2 = s_2 + wr_2;

%% Decision Making
y_decis = y_2 - y_1;
logi = y_decis.*( 2*bit - ones(num, n)) < 0;
prob_b122 = sum(logi)/num;

figure(122);
semilogy(SNR, prob_b122, DisplayName= "Actual BER");
xlabel(" SNR (dB)", Interpreter="latex");
ylabel("BER",Interpreter="latex");
title("Bit Error Rate for Q2",Interpreter="latex");
hold on 
semilogy(SNR, pb121, DisplayName= "Theoretic BER");
legend
grid on

save("../Part3/prob121.mat", "pb121");
save("../Part4/prob121.mat", "pb121");
save("../Part3/prob122.mat", "prob_b122");

