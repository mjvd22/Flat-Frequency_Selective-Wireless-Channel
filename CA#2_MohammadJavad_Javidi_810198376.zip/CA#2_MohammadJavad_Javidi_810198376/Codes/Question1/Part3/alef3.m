clc; clear; close all;


a = 1;
SNR = linspace( -20, 60, 1000);
N0 = a^2./10.^(SNR/10);

gamma = 2*10.^(SNR/10);
Pe_avg131 = 0.5*( 1 - (gamma./(1+gamma)).^0.5);

figure(131);
semilogy(SNR, Pe_avg131,DisplayName= "Theoretical $Pe_{avg}$");
xlabel(" SNR (dB)", Interpreter="latex");
ylabel("Theoretical Average Error Probability", Interpreter="latex");
title("Theoretical Average Error Probability in Q3", Interpreter="latex");
legend(Interpreter="latex")
grid on 