clear; clc; %close all
%% Defining Parameters
    BitPerSymbol=1; % bit/symbol
    NoSymbols=10^6; % symbol numbers
    NoSub=10^4; % Subcarries number
    p_max = NoSub/10;
    LenCyclic=199; % Length of Cyclic prefix
    SNR=-20:1:40;
    eqz_opt_1 = "ZF"; % Equalizer Type
    eqz_opt_2 = "MMSE"; % Equalizer Type
%     BPSKNum=2; % Phase number of BPSK
%% BPSK Symbol Making 
    % Gnerate Data Sequence
    rng("shuffle")
    NoBits=NoSymbols;
    data=randi([0 1],1,NoBits);
    % Separate data to different path and different SNR
    path=reshape(data,NoSub,NoBits/NoSub);
    % BPSK
%     BPSKpath=2.*path - ones(NoSub,NoBits/NoSub);
    BPSKpath = dpskmod(path, 2);
    clear path main_path;
%% Equalizer
    
    BER_ZF = Equalizer(SNR, BPSKpath, p_max, NoSub, LenCyclic, data, eqz_opt_1);
    BER_MMSE = Equalizer(SNR, BPSKpath, p_max, NoSub, LenCyclic, data, eqz_opt_2);
%% Plot result
    fig(1) = figure;
    semilogy(SNR,BER_ZF, '--o',DisplayName="ZF method");
    grid on
    xlabel('SNR[dB]', Interpreter='latex');
    ylabel('BER', Interpreter='latex');
    title(["OFDM with ZF method"], Interpreter='latex')
    fig(2) = figure;
    semilogy(SNR,BER_MMSE, '--*',DisplayName="MMSE method");
    grid on
    xlabel('SNR[dB]', Interpreter='latex');
    ylabel('BER', Interpreter='latex');
    title(["OFDM with MMSE method"], Interpreter='latex')
    fig(3) = figure;
    semilogy(SNR,BER_ZF, '--o', DisplayName="ZF method");
    grid on
    hold on
    semilogy(SNR,BER_MMSE, '--*', DisplayName="MMSE method");
    legend(Interpreter="latex")
%% Functions
function Pe = Equalizer(SNR, BPSKpath, p_max, NoSub, LenCyclic, data, eqz_opt)
    N_0 = (p_max./((10.^(SNR./10)) *NoSub) )'; % Noise Energy
    parfor SnrNo = 1:length(SNR)
        rng(1)
    
        % channel coefficients
        hr_main = sqrt(0.5).*randn(LenCyclic+1, 1);
        hi_main = sqrt(0.5).*randn(LenCyclic+1, 1);
        h_main = hr_main + 1j.*hi_main;
        h = repmat(h_main, [1, size(BPSKpath, 2)]);
        H = fft(h, NoSub, 1);

        % Adding CP and Transmitting
        % ifft
        ifftpath=ifft(BPSKpath,NoSub, 1);
        % Add cyclic prefix
        Tranpath=zeros(size(ifftpath,1)+LenCyclic,size(ifftpath,2));
        Tranpath(1:LenCyclic,:, :)=ifftpath((end-LenCyclic+1):end,:);
        Tranpath((1+LenCyclic):end,:)=ifftpath;
         
        % Transmitting
        Repath = transmit(h_main, Tranpath);
        
        % noise generating
        ni = sqrt(N_0(SnrNo)/2).*randn(size(Repath));
        nr = sqrt(N_0(SnrNo)/2).*randn(size(Repath));
        n = nr+1j.*ni;
%         clear ni nr;

        Repath = Repath + n;
        
        % Receiver and Decision making

        % Remove cyclic prefix
        ReCyclicpath = Repath((1+LenCyclic):end,:);
        % fft
        fftpath=fft(ReCyclicpath,NoSub, 1);
        
        % Eqz
        if (eqz_opt == "ZF")
            Repath_eqz = fftpath./(H);
        elseif(eqz_opt == "MMSE")
            Repath_eqz = fftpath.*( conj(H)./(H.*conj(H) + repmat(N_0(SnrNo), size(H))));
%             Repath_eqz = fftpath.*( conj(H)./(abs(H.^2)) );
        end


        % Reform
%         demodata=reshape(real(Repath_eqz),[1,size(fftpath,1)*size(fftpath,2)]);
        demodata=reshape(dpskdemod(Repath_eqz, 2),[1,size(fftpath,1)*size(fftpath,2)]);
%         data_branch = repmat(data, [1, ]);
        % Calculate BER
        Pe(SnrNo)=sum(demodata.*(2.*data - 1) < 0 )/(size(fftpath,1)*size(fftpath,2));
        
    end
end
function res = transmit(chnl, data)
     res = zeros(size(data));
    parfor block = 1:size(data, 2)
        res(:, block) = cconv(data(:, block), chnl, length(data(:, block)));
    end
    
end