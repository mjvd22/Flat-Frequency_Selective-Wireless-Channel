clc; clear; close all;
%% Defining Parameters
num = 1e5;

a = 1;
SNR = linspace(-20, 20, 1000);
gamma = 10.^(SNR/10);
n = length(SNR);

N0 = a^2./10.^(SNR/10);


%% Defining bits and modulation QPSK
N = repmat(N0, [num, 1]);
%bits:
bit_horiz = randi([0, 1], [num, n]);
bit_vert = randi([0, 1], [num, n]);

s1 = a*( 2*(bit_horiz > 0)- ones( num, n));
s2 = a*( 2*(bit_vert > 0) - ones( num, n));
%% Defining Channel Coefficients and noise
hr = sqrt(1/2)*randn( num, n);
hi = sqrt(1/2)*randn( num, n);

wr_horiz = sqrt(N/4).*randn( num, n);
wi_horiz = sqrt(N/4).*randn( num, n);
w_horiz = wr_horiz + 1j.*wi_horiz;
clear wi_horiz wr_horiz
wr_ver = sqrt(N/4).*randn( num, n);
wi_ver = sqrt(N/4).*randn( num, n);
w_ver = wr_ver + 1j.*wi_ver;
clear wr_ver wi_ver

% h2 = hr.^2 + hi.^2;
h2 = hr + 1j.*hi;
clear hr hi
% noiser_horiz = (wr_horiz.*hr + wi_horiz.*hi)./h2;
noiser_horiz = (conj(h2).*w_horiz)./(abs(h2).^2);
% noiser_ver = (wr_ver.*hr + wi_ver.*hi)./h2;
noiser_ver = (w_ver.*conj(h2))./(abs(h2).^2);
%% Receiver and Decision Making
y_horiz = s1 + noiser_horiz;
y_ver = s2 + noiser_ver;

% s1 and s2 have been correcty detected:
logi = (s1.*y_horiz >0).*( s2.*y_ver > 0);
pe141b = 1 - sum(logi)/num;

pe141a = ( 1 - (2.*gamma./(1+2.*gamma)).^0.5);

figure(141);
semilogy( SNR, pe141a, SNR, pe141b);
legend([" Theoretical", " Simulation"], Interpreter="latex");
xlabel(" SNR (dB)", Interpreter="latex");
ylabel("Average Error Probability", Interpreter="latex");
title("Average Error Probability in QPSK ", Interpreter="latex");
grid on

figure(1411);
p1 = load("prob121.mat").pb121;
p2 = load("prob131.mat").Pe_avg131;
p3 = pe141a;
semilogy(SNR, p1,SNR, p2, '.-',SNR, p3, '--');
legend(["BPSK No Fading", "BPSK with Fading", "QPSK with Fading"], Interpreter="latex");
xlabel(" SNR (dB)", Interpreter="latex");
ylabel("Average Error Probability", Interpreter="latex");
title("Comapring BPSK and QPSK", Interpreter="latex")
ylim([1e-5 1e0 ])
grid on 